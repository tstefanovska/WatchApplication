package com.example.teast.watchapplication.Data;

public class MenuModel {

    public int icon;
    public String name;


    public MenuModel(int icon, String name) {
        this.icon = icon;
        this.name = name;
    }
}
