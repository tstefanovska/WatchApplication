package com.example.teast.watchapplication;

import android.app.IntentService;
import android.content.Intent;

public class NotificationService extends IntentService {
    public NotificationService(){super("NotificationService");}
    @Override
    protected void onHandleIntent(Intent intent) {

    }
}
